export type Color = 'W' | 'Y' | 'R' | 'O' | 'B' | 'G';

export const COLORS: Record<Color, string> = {
  W: 'bg-white',
  Y: 'bg-amber-400',
  R: 'bg-red-600',
  O: 'bg-orange-500',
  B: 'bg-blue-600',
  G: 'bg-emerald-600',
};

// Official competition Rubik's palette with crisp, vibrant lighting
export const COLOR_STYLES: Record<Color, { bg: string; border: string; highlight: string; name: string; hex: string }> = {
  W: {
    bg: 'linear-gradient(135deg, #ffffff 0%, #edf2f7 100%)',
    border: '#cbd5e1',
    highlight: 'rgba(255, 255, 255, 0.95)',
    name: 'White',
    hex: '#ffffff',
  },
  Y: {
    bg: 'linear-gradient(135deg, #ffe019 0%, #f5c400 100%)',
    border: '#d9a300',
    highlight: 'rgba(255, 248, 175, 0.85)',
    name: 'Yellow',
    hex: '#ffd700',
  },
  R: {
    bg: 'linear-gradient(135deg, #f43f5e 0%, #e11d48 100%)',
    border: '#be123c',
    highlight: 'rgba(254, 205, 211, 0.75)',
    name: 'Red',
    hex: '#e11d48',
  },
  O: {
    bg: 'linear-gradient(135deg, #ff7a1a 0%, #ff5500 100%)',
    border: '#c2410c',
    highlight: 'rgba(254, 215, 170, 0.75)',
    name: 'Orange',
    hex: '#ff6600',
  },
  B: {
    bg: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
    border: '#1e40af',
    highlight: 'rgba(191, 219, 254, 0.75)',
    name: 'Blue',
    hex: '#2563eb',
  },
  G: {
    bg: 'linear-gradient(135deg, #16a34a 0%, #15803d 100%)',
    border: '#166534',
    highlight: 'rgba(187, 247, 208, 0.75)',
    name: 'Green',
    hex: '#16a34a',
  },
};

export type FaceName = 'F' | 'B' | 'U' | 'D' | 'L' | 'R';

export const ALL_FACES: FaceName[] = ['F', 'B', 'U', 'D', 'L', 'R'];

export type Axis = 'x' | 'y' | 'z';

export interface CubieState {
  id: number;
  position: [number, number, number];
  colors: Partial<Record<FaceName, Color>>;
}

export type CubeState = CubieState[];

export interface FaceRotation {
  axis: Axis;
  slice: number;
  direction: 1 | -1;
}

export type MoveNotation =
  | 'R' | "R'" | 'L' | "L'"
  | 'U' | "U'" | 'D' | "D'"
  | 'F' | "F'" | 'B' | "B'";

export interface MoveDefinition {
  notation: MoveNotation;
  axis: Axis;
  slice: number;
  direction: 1 | -1;
  label: string;
}

export const STANDARD_MOVES: Record<MoveNotation, { axis: Axis; slice: number; direction: 1 | -1; label: string }> = {
  R: { axis: 'x', slice: 1, direction: 1, label: 'Right' },
  "R'": { axis: 'x', slice: 1, direction: -1, label: 'Right CCW' },
  L: { axis: 'x', slice: -1, direction: -1, label: 'Left' },
  "L'": { axis: 'x', slice: -1, direction: 1, label: 'Left CCW' },
  U: { axis: 'y', slice: -1, direction: -1, label: 'Up' },
  "U'": { axis: 'y', slice: -1, direction: 1, label: 'Up CCW' },
  D: { axis: 'y', slice: 1, direction: 1, label: 'Down' },
  "D'": { axis: 'y', slice: 1, direction: -1, label: 'Down CCW' },
  F: { axis: 'z', slice: 1, direction: 1, label: 'Front' },
  "F'": { axis: 'z', slice: 1, direction: -1, label: 'Front CCW' },
  B: { axis: 'z', slice: -1, direction: -1, label: 'Back' },
  "B'": { axis: 'z', slice: -1, direction: 1, label: 'Back CCW' },
};
