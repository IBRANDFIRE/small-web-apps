import React from 'react';
import { X, Hand, Smartphone, Orbit, ZoomIn, EyeOff, Keyboard, Monitor } from 'lucide-react';

interface HowToPlayModalProps {
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-[#11131a] border border-[#242836] rounded-3xl p-4 sm:p-5 shadow-2xl text-neutral-200 max-h-[88vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#242836] flex-shrink-0">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-base sm:text-lg text-white">How to Play & Controls</h3>
            <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
              All Devices
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white bg-[#1a1d27]"
            aria-label="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto pr-1 my-3 flex flex-col gap-2.5 text-xs sm:text-sm">
          {/* Section: Mobile Phones & Tablets / Pads */}
          <div className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5 pt-1">
            <Smartphone className="w-3.5 h-3.5 text-blue-400" />
            <span>Mobile Phones & Pads (Touch)</span>
          </div>

          {/* 2-Finger Zoom */}
          <div className="flex items-start gap-3 p-2.5 rounded-xl bg-[#161922] border border-[#222736]">
            <ZoomIn className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold text-white block text-xs sm:text-sm">2-Finger Pinch Zoom</span>
              <span className="text-neutral-400 text-[11px] sm:text-xs">
                Pinch in or out with two fingers on any touch screen to smoothly inspect corners or view the whole cube.
              </span>
            </div>
          </div>

          {/* Slice Turn */}
          <div className="flex items-start gap-3 p-2.5 rounded-xl bg-[#161922] border border-[#222736]">
            <Hand className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold text-white block text-xs sm:text-sm">Swipe Colored Stickers to Turn</span>
              <span className="text-neutral-400 text-[11px] sm:text-xs">
                Touch and swipe directly across any row or column to turn that 3D slice in the swiped direction.
              </span>
            </div>
          </div>

          {/* Orbit Camera */}
          <div className="flex items-start gap-3 p-2.5 rounded-xl bg-[#161922] border border-[#222736]">
            <Orbit className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold text-white block text-xs sm:text-sm">Orbit Camera View</span>
              <span className="text-neutral-400 text-[11px] sm:text-xs">
                Drag with 1 finger on the background (or click-drag with mouse) to freely orbit all 6 sides.
              </span>
            </div>
          </div>

          {/* Section: Computers & Laptops */}
          <div className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5 pt-2">
            <Monitor className="w-3.5 h-3.5 text-emerald-400" />
            <span>Computers & Laptops (Mouse & Keyboard)</span>
          </div>

          {/* Keyboard Speedcube Controls */}
          <div className="flex items-start gap-3 p-2.5 rounded-xl bg-[#161922] border border-[#222736]">
            <Keyboard className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div className="w-full">
              <span className="font-semibold text-white block text-xs sm:text-sm">Speedcube Keyboard Keys</span>
              <div className="grid grid-cols-2 gap-1.5 mt-1.5 text-[11px] text-neutral-300">
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">U</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">L</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">F</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">R</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">B</kbd>, <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">D</kbd> : Turn face</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">Shift</kbd> + Face : Inverse (') turn</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">Space</kbd> : Scramble cube</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">Z</kbd> : Undo last move</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">Arrow Keys</kbd> : Orbit camera</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">+</kbd> / <kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">-</kbd> : Zoom in / out</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">H</kbd> : Hide / Show all menus</div>
                <div><kbd className="px-1.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-white font-mono">Scroll Wheel</kbd> : Zoom cube</div>
              </div>
            </div>
          </div>

          {/* Hide UI Mode */}
          <div className="flex items-start gap-3 p-2.5 rounded-xl bg-[#161922] border border-[#222736]">
            <EyeOff className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-semibold text-white block text-xs sm:text-sm">Hide All Menus Mode</span>
              <span className="text-neutral-400 text-[11px] sm:text-xs">
                Tap the eye icon or press <kbd className="px-1 py-0.5 rounded bg-neutral-800 text-white font-mono text-[10px]">H</kbd> to hide all buttons for a distraction-free full screen. Tap "Show Menus" to restore.
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-2 border-t border-[#242836] flex-shrink-0">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl font-bold bg-blue-600 hover:bg-blue-500 text-white transition shadow-lg shadow-blue-600/30 text-xs sm:text-sm"
          >
            Got it, let's play!
          </button>
        </div>
      </div>
    </div>
  );
};

export default HowToPlayModal;
