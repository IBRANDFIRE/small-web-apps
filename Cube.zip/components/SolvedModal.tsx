import React from 'react';
import { Trophy, Shuffle, RotateCcw, X } from 'lucide-react';

interface SolvedModalProps {
  moveCount: number;
  timeFormatted: string;
  onScramble: () => void;
  onReset: () => void;
  onClose: () => void;
}

export const SolvedModal: React.FC<SolvedModalProps> = ({
  moveCount,
  timeFormatted,
  onScramble,
  onReset,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-neutral-900 border border-neutral-700/80 rounded-3xl p-4 sm:p-6 shadow-2xl flex flex-col items-center text-center max-h-[90vh] overflow-y-auto relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1.5 rounded-lg text-neutral-400 hover:text-white bg-neutral-800"
          aria-label="Close"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Glowing Trophy Badge */}
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mb-3 sm:mb-4 text-amber-400 shadow-lg shadow-amber-500/20 flex-shrink-0">
          <Trophy className="w-8 h-8 sm:w-9 sm:h-9" />
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
          Cube Solved!
        </h2>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1">
          Every face is completely uniform. Incredible solve!
        </p>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3 w-full my-4 sm:my-5">
          <div className="flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-2xl bg-neutral-800/80 border border-neutral-700/50">
            <span className="text-[11px] sm:text-xs text-neutral-400 font-medium">Moves</span>
            <span className="text-xl sm:text-2xl font-extrabold text-white mt-0.5">{moveCount}</span>
          </div>
          <div className="flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-2xl bg-neutral-800/80 border border-neutral-700/50">
            <span className="text-[11px] sm:text-xs text-neutral-400 font-medium">Time</span>
            <span className="text-xl sm:text-2xl font-extrabold text-amber-400 mt-0.5">{timeFormatted}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col w-full gap-2">
          <button
            onClick={onScramble}
            className="w-full py-2.5 sm:py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 active:scale-95 transition"
          >
            <Shuffle className="w-4 h-4" />
            <span>Scramble & Solve Again</span>
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onReset}
              className="py-2 sm:py-2.5 px-3 sm:px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
            <button
              onClick={onClose}
              className="py-2 sm:py-2.5 px-3 sm:px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs flex items-center justify-center active:scale-95 transition"
            >
              <span>Inspect</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolvedModal;
